"""Version information for Synapse Language"""

__version__ = "2.3.0"
__version_info__ = (2, 3, 0)
__release_date__ = "2025-09-18"

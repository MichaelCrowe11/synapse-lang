"""Placeholder package for future packaged Quantum Net language.
Currently retains legacy root modules (quantum_net_*.py)."""

def placeholder():
    return "quantum_net_lang placeholder"

__all__ = ["placeholder"]

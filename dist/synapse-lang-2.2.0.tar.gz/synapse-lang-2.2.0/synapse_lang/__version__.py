"""Version information for Synapse Language"""

__version__ = "1.0.2"
__version_info__ = (1, 0, 2)
__release_date__ = "2025-01-08"

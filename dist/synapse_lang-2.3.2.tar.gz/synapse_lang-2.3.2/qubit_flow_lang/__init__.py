"""Placeholder package for future packaged Qubit Flow language.
Currently retains legacy root modules (qubit_flow_*.py)."""

def placeholder():
    return "qubit_flow_lang placeholder"

__all__ = ["placeholder"]

"""Qubit-Flow Quantum Computing Language - Part of the Quantum Trinity"""

__version__ = "1.0.0"
